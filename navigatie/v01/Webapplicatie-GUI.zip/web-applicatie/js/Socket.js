$(document).ready(function () {
    //create a new WebSocket object.
    var wsUri = "ws://169.254.34.182:12345/Kadaster/server.php";
    var bocht_delay = 0;

    websocket = new WebSocket(wsUri);
    websocket.onopen = function (ev) { // connection is open
        console.log("Connection is open");
    }

    //#### Message received from server?
    websocket.onmessage = function (ev) {
        var msg = JSON.parse(ev.data); //PHP sends Json data
        var test = msg.test;
        if (test == 'bestemming') {
            $('#bestemming').show();
            throw new Error("Bestemming Bereikt!");
        }
        var parts = test.split(',');
        //console.log(parts);

        var datum = parts[0];
        var tijd = parts[1];
        var longitude = parts[2];
        var latitude = parts[3];
        var afstand_tov_ref = parts[4];
        var afstand_tov_eind_lijn = parts[5];
        var kant_van_lijn = parts[6];
        var azimuth_lijn = parts[7];
        var azimuth_eind_lijn = parts[8];
        var bocht = parts[9];
        var hoek_bocht = parts[10];
        var degrees = azimuth_eind_lijn - azimuth_lijn;

        //$('#kant').html(kant_van_lijn);
        console.log(kant_van_lijn);
        if (kant_van_lijn == 'links') {
            $('#links').html("<span style='opacity: .10;' class='glyphicon glyphicon-chevron-left'></span>");
            $('#rechts').html("<span class='glyphicon glyphicon-chevron-right'></span>");
        }
        if (kant_van_lijn == 'rechts') {
            $('#links').html("<span style=''class='glyphicon glyphicon-chevron-left'></span>");
            $('#rechts').html("<span style='opacity: .10;' class='glyphicon glyphicon-chevron-right'></span>");
        }
        console.log(bocht_delay)

        if (bocht != 'False') {

            bocht_delay = 1;
            console.log(bocht_delay);
            console.log(bocht)

            if (bocht == 'rechts') {
                $('#nav-arrow').html("<span class='nav-arrow glyphicon glyphicon-share-alt'></span>");
            } else {
                $('#nav-arrow').html("<span style='-moz-transform: scaleX(-1); -o-transform: scaleX(-1); -webkit-transform: scaleX(-1); transform: scaleX(-1); filter: FlipH; -ms-filter: 'FlipH';' class='nav-arrow glyphicon glyphicon-share-alt'></span>");
            }
            
            $('#a_eind').html(parseFloat(hoek_bocht).toFixed(2) + " graden");
            
            setTimeout(function () {
                bocht_delay = 0;
            }, 4000);

        }
        $('#a_lijn').html(parseFloat(afstand_tov_ref).toFixed(2) + " meter");
        if (bocht_delay == 0) {

            console.log('turning arrow')
            $('#nav-arrow').html("<span style='-webkit-transform: rotate(" + degrees + "deg); -moz-transform: rotate(" + degrees + "deg); -o-transform: rotate(" + degrees + "deg); -ms-transform: rotate(" + degrees + "deg); transform: rotate(" + degrees + "deg);' class='nav-arrow glyphicon glyphicon-arrow-up'></span>");
            $('#a_eind').html(parseFloat(afstand_tov_eind_lijn).toFixed(2) + " meter");
            
        }

    };

    websocket.onerror = function (ev) {
        console.log("Connection error");
    };

    websocket.onclose = function (ev) {
        console.log("Connection is closed");
    };

});
