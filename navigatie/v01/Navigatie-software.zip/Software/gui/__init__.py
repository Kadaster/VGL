#Auteurs: G. Roelofs, T. Dantuma, J. Klinkhamer, T. Iedema, M. Jahangier.

from tkinter import *
import math
#maak nieuwe GUI aan

nGui = Tk()

#globals:
routes = []
gekozen_route = ''
dropdown = '' #dropdown menu met routes
tlabel = '' #textlabel met de richting (rechts of links)
alabel = '' #textlabel met de afstand
a_e_label = '' #afstand tot eind label
canvas_width = 200
canvas_height = 200
canvas = ''
pijl = '' #pijl die naar het eindpunt van een lijn wijst
rlabel = '' #route naam
lnlabel = 0 #lijn nummer
blabel = '' #als er een bocht is.
elabel = '' #einde
forceLijnbutton = ''
lijnnummer_update = False

def setLijnnummerUpdate(Bool):
    global lijnnummer_update
    if Bool:
        lijnnummer_update = True
    else:
        lijnnummer_update = False

def forceLijnNummer():
    global lijnnummer_update
    lijnnummer_update = True

def getGekozenRoute():
    return gekozen_route

def updateBocht(graden):
    global blabel
    if graden == False:
        #er is geen bocht haal de label weg.
        blabel.configure(text = ('Doorlopen...'))
    else:
        blabel.configure(text = ('Bocht: ',  "%.3f" % graden, ' graden'))

def updateLijnNummer(nummer):
    global lnlabel
    lnlabel.configure(text = ('Lijn: ', nummer + 1))

def setRoute(route):
    global gekozen_route
    gekozen_route = route
    dropdown.pack_forget()

    global rlabel
    rlabel = Label(nGui, text=route)
    rlabel.pack(side="top")

    global forceLijnbutton
    forceLijnbutton = Button(nGui, text="Forceer volgende lijn", command=forceLijnNummer)
    forceLijnbutton.pack(side="bottom")

def createGui():
    #titel zetten
    nGui.title('GUI')

    if gekozen_route == '':
        #menu opzetten:
        OPTIONS = []
        for route in routes[0]:
            OPTIONS.append(route[0])

        variable = StringVar(nGui)
        variable.set(OPTIONS[0]) # default value
        global dropdown
        dropdown = OptionMenu(nGui, variable, *OPTIONS, command = setRoute)
        dropdown.pack()

    #eerste labels tekenen
    global tlabel
    tlabel = Label(nGui, text="richting")
    tlabel.pack(side="top")

    #creer de label voor de bocht.
    global blabel
    blabel = Label(nGui, text="bocht in graden")
    blabel.pack(side="top")

    global alabel
    alabel = Label(nGui, text="afstand")
    alabel.pack(side="top")

    global a_e_label
    a_e_label = Label(nGui, text="afstand t.o.v. eind lijn")
    a_e_label.pack(side="top")

    #canvas tekenen
    global canvas
    canvas = Canvas(nGui, width=canvas_width, height=canvas_height, bg="white")
    canvas.pack()

    #eerste cirkel tekenen
    canvas.create_oval(canvas_width/2-50,canvas_height/2-50,canvas_width/2+50,canvas_height/2+50)

    global pijl
    pijl = canvas.create_line(canvas_width/2,canvas_height/2,canvas_width/2,canvas_height/2-50,fill="red")

    global lnlabel
    lnlabel = Label(nGui, text="Lijn nummer")
    lnlabel.pack(side="bottom")

def setRoutes(routeLijst):
    routes.append(routeLijst)

#update je richting die je op moet lopen
def updateRichtingText(richting):
    new_text = richting
    tlabel.configure(text = new_text)

#update de afstand tot het eindpunt van de huidige lijn
def updateAfstandEind(distance):
    a_e_label.configure(text = ('T.o.v. eind: ', "%.3f" % distance,"m"))
#update de afstand
def updateAfstand(distance):
    alabel.configure(text = ('T.o.v. ref: ', "%.3f" % distance,"m"))

#update de de cirkel met de richting
def updateRichting(som):

    if som > 90:
        hoek = som - 90
    else:
        hoek = som + 270
    canvas.delete(ALL)
    #aanpassen naar juiste hoek
    angle_in_degrees = hoek
    angle_in_radians = angle_in_degrees * math.pi / 180
    line_length = 75
    center_x = canvas_width/2
    center_y = canvas_height/2
    end_x = center_x + line_length * math.cos(angle_in_radians)
    end_y = center_y + line_length * math.sin(angle_in_radians)
    pijl = canvas.create_line(center_x,center_y,end_x,end_y)

    canvas.create_oval(canvas_width/2-50,canvas_height/2-50,canvas_width/2+50,canvas_height/2+50)
    pijl = canvas.create_line(canvas_width/2,canvas_height/2,canvas_width/2,canvas_height/2-50,fill="red")

#update de GUI
def updateGui():
    nGui.update()
