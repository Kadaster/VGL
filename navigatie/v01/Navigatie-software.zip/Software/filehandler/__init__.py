#Auteurs: G. Roelofs, T. Dantuma, J. Klinkhamer, T. Iedema, M. Jahangier.

import datetime

def readFile():
    print('reading')

def createFile():
    timestamp = datetime.datetime.now()
    timestamp = str(timestamp)
    timestamp = timestamp.replace(" ", "_")
    timestamp = timestamp.replace(":", "-")
    file_name = str('output/')+timestamp+str('_output.txt')
    #print(file_name)
    file_name = str(file_name)
    #print('writing')
    text_file = open(file_name, "w")
    lines = ["Datum", ",",
             "Time", ",",
             "Longitude", ",",
             "Latitude", ",",
             "Afstand_tov_ref", ",",
             "Afstand_tov_eind_lijn", ",",
             "Kant_van_lijn", ",",
             "Azimuth_lijn", ",",
             "Azimuth_eind_lijn", ",",
             "Bocht", ",",
             "Hoek_bocht", "\n"]
    text_file.writelines(lines)
    text_file.close()

    output_file = open('output/arduino/output.txt', "w")
    output_file.close()

    return file_name

def writeToFile(output_log, data):

    text_file = open(output_log, "a")
    text_file.writelines(data)
    text_file.close()

    data.remove('\n')
    output_file = open('output/arduino/output.txt', "a")
    output_file.writelines(data)
    output_file.close()
