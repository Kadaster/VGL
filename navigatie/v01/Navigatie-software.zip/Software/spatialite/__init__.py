#Auteurs: G. Roelofs, T. Dantuma, J. Klinkhamer, T. Iedema, M. Jahangier.

import sqlite3
import math
from haversine import haversine
import subprocess
#------------------------------------Database verbinding opzetten--------------------------------------
def connect(database):
    conn = sqlite3.connect(database)
    conn.enable_load_extension(True)
    cursor = conn.execute('SELECT load_extension("mod_spatialite.dll")').fetchall()
    return conn

def getRoutes(conn):
    #haal alle tabellen op die een route zijn:
    tables = conn.execute("select name from sqlite_master where type='table' and name not like '%spatial%' and name not like '%geo%' and name not like '%sql%'").fetchall()

    return tables

def getRoute(conn, route):

    #Haal de route op:
    db_route = conn.execute('SELECT Astext(Geometry) from '+route+'').fetchall()
    geplande_route = []
    for row in db_route:
        #verwijder tekens:
        row = row[0]
        row = row.replace('(', '')
        row = row.replace(')', '')
        row = row.replace(",", '')

        #controlleer wat er verwijderd moet worden:
        if 'LINESTRING' in row:
            row = row.replace('LINESTRING', '')
        if 'MULTILINE' in row:
            row = row.replace('MULTILINE', '')
        if 'POLYGON' in row:
            row = row.replace('POLYGON', '')

        #Zet het in een list:
        lijn_xy = str.split(row)
        lijn_yx = []
        coordinaat_start = float(lijn_xy[1]),float(lijn_xy[0])
        coordinaat_eind = float(lijn_xy[3]),float(lijn_xy[2])
        lijn_yx.append(coordinaat_start)
        lijn_yx.append(coordinaat_eind)
        geplande_route.append(lijn_yx)

    return geplande_route

def getStartRoute(route):
    return route[0][0]

def getEindRoute(route):
    lengte = len(route)
    return route[lengte - 1][1]

#def getEindLijn(lijn):
    #lengte_lijst = len(lijn)
    #print('getEindLijn() - laatste punt:', lijn[lengte_lijst - 1])
    #laatste_punt = lijn[lengte_lijst - 1]
    #return laatste_punt

#def getStartLijn(lijn):
    #return lijn[0]

def getGradenLijn(conn, coordinaat_a, coordinaat_b):
    radius = conn.execute('SELECT Azimuth(MakePoint('+str(coordinaat_a[1])+','+str(coordinaat_a[0])+'),MakePoint('+str(coordinaat_b[1])+','+str(coordinaat_b[0])+'))').fetchall()
    graden = radius[0][0] * 180 / math.pi
    #print('getGradenLijn() - radius: ', radius[0][0])
    #print('getGradenLijn() - graden: ', graden)
    return graden

def rechtsVanLijn(graden_lijn,graden_positie):

    HL = graden_lijn #huidige lijn
    VL = graden_positie #volgende lijn

    if HL > 180:
        contra = HL - 180 #als HL 4 is dan is contra 184.
    else:
        contra = HL + 180

    #return 0 > links t.o.v. de lijn
    #return 1 > rechts t.o.v. de lijn
    if contra <= VL <= HL:
        return 0
    elif HL <= contra <= VL:
        return 0
    elif VL <= HL < contra:
        return 0
    else:
        return 1

    #if(graden_lijn < 180):
    #    graden_tegenover_lijn = graden_lijn + 180
    #else:
    #    graden_tegenover_lijn = graden_lijn - 180
    #if(graden_positie < graden_lijn and graden_positie > graden_tegenover_lijn):
        #je loopt links van de lijn
    #    return 0
    #else:
        #je loopt rechts van de lijn
    #    return 1

def interpolate(lijn, referentie_afstand):

    #------------------------------------Te lopen lijn indelen met referentie punten--------------------------------------

    #we willen het gewenste aantal referentie punten op de lijn tekenen:
    lijn_afstand_meters = haversine(lijn[0], lijn[1]) * 1000
    #we willen om de (bijvoorbeeld halve meter) een punt.
    #2 punten er af omdat we dat als start en eind punt al hebben
    aantal_ref_punten = lijn_afstand_meters / referentie_afstand
    aantal_ref_punten = int(aantal_ref_punten)

    #teken punten tussen begin en eind:

    #bereken het verschil tussen de x en y van start en eind
    #controlleer welke x waarde het grootste is ivm met de som
    if lijn[0][1] > lijn[1][1]:
        verschil_lijn_x = lijn[0][1] - lijn[1][1]
    else:
        verschil_lijn_x = lijn[1][1] - lijn[0][1]

    #controlleer welke y waarde het grootste is ivm met de som
    if lijn[0][0] > lijn[1][0]:
        verschil_lijn_y = lijn[0][0] - lijn[1][0]
    else:
        verschil_lijn_y = lijn[1][0] - lijn[0][0]

    #bereken de som waarmee x en y coordinaten berekend moeten worden:
    som_x = verschil_lijn_x / aantal_ref_punten
    som_y = verschil_lijn_y / aantal_ref_punten

    interpolated_lijn = []
    interpolated_lijn.append(lijn[0])

    x_oud = lijn[0][1]
    y_oud = lijn[0][0]
    aantal_geplaatste_punten = 0
    #loop om alle punten in de geplande lijn toe te voegen:
    while(aantal_geplaatste_punten < aantal_ref_punten-2):
        if lijn[0][0] < lijn[1][0]:
            y_nieuw = y_oud + som_y
        else:
            y_nieuw = y_oud - som_y

        if lijn[0][1] < lijn[1][1]:
            x_nieuw = x_oud + som_x
        else:
            x_nieuw = x_oud - som_x

        Coordinaat = y_nieuw, x_nieuw
        interpolated_lijn.append(Coordinaat)

        x_oud = x_nieuw
        y_oud = y_nieuw
        aantal_geplaatste_punten = aantal_geplaatste_punten + 1

    interpolated_lijn.append(lijn[1])
    #test = str(interpolated_lijn)
    #test = test.replace(',','')
    #test = test.replace(')','"')
    #test = test.replace('(','"')
    #print(test)
    return interpolated_lijn

def getClosestPoint(HP,A,B):
        afstand_a = haversine(HP, A)
        afstand_b = haversine(HP, B)
        if afstand_a < afstand_b:
            print('getClosestPoint ', A, 'Afstand ',afstand_a * 1000)
            return A
        else:
            print('getClosestPoint ', B, 'Afstand ',afstand_b * 1000)
            return B

def getReferentiePunt(interpolated_lijn, huidige_positie):
    running = True
    lengte_lijst = len(interpolated_lijn)
    min_lijst_nummer = int(0)
    max_lijst_nummer = int(lengte_lijst-1)

    i = 1
    while(running == True):

        mid_lijst_nummer = min_lijst_nummer + ((max_lijst_nummer - min_lijst_nummer) / 2)
        mid_lijst_nummer = int(mid_lijst_nummer)

        #print('aantal keer doorlopen', i)
        #print(min_lijst_nummer)
        #print(mid_lijst_nummer)
        #print(max_lijst_nummer)
        #print('')
        i = i + 1
        #bepaal afstand tot begin en eind.
        afstand_min_lijst = haversine(huidige_positie, interpolated_lijn[min_lijst_nummer])
        afstand_max_lijst = haversine(huidige_positie, interpolated_lijn[max_lijst_nummer])
        #print('afstand_min_lijst',afstand_min_lijst * 1000)
        #print('afstand_max_lijst',afstand_max_lijst * 1000)
        if min_lijst_nummer + 1 == max_lijst_nummer:
            #we hebben nog maar 2 mogelijkheden over. we kiezen dus de dichtbijzijnste
            if afstand_min_lijst < afstand_max_lijst:
                ref_punt = interpolated_lijn[int(min_lijst_nummer)]
            else:
                ref_punt = interpolated_lijn[int(max_lijst_nummer)]
            running = False

        elif afstand_min_lijst < afstand_max_lijst:
            max_lijst_nummer = mid_lijst_nummer
            status = 'omhoog'
        else:
            min_lijst_nummer = mid_lijst_nummer
            status = 'omlaag'

        mid_lijst_nummer = min_lijst_nummer + ((max_lijst_nummer - min_lijst_nummer) / 2)
        mid_lijst_nummer = int(mid_lijst_nummer)
        #is het lengte van de lijst oneven?
        #zo ja, dit is niet deelbaar door 2 en moet er dus afgerond worden.
        if max_lijst_nummer % 2 == 1:
            if status == 'omhoog':
                mid_lijst_nummer = mid_lijst_nummer + 1
                mid_lijst_nummer = int(mid_lijst_nummer)
            elif status == 'omlaag':
                mid_lijst_nummer = int(mid_lijst_nummer)
    #print('Referentie punt: ', ref_punt)
    return ref_punt

def updateLijn(huidige_positie, lijn_eind, afstand_trigger):
    #print('UpdateLijn() - huidige_positie: ', huidige_positie)
    #print('UpdateLijn() - laatste punt: ', lijn_eind)
    #print('UpdateLijn() - afstand_trigger: ', afstand_trigger)
    afstand_meters = haversine(huidige_positie, lijn_eind) * 1000
    #print('UpdateLijn() - afstand_meters: ', afstand_meters)
    if afstand_meters < afstand_trigger:
        return True
    else:
        return False

def getHoekVolgendeLijn(route, lijn_nummer):

        #korte kant (huidige lijn) driehoek:
        A = haversine(route[lijn_nummer][0], route[lijn_nummer][1])
        #korte kant (volgende lijn) driehoek:
        B = haversine(route[lijn_nummer + 1][0], route[lijn_nummer + 1][1])
        #lange kant (start huidige + eind volgende lijn ) driehoek:
        C = haversine(route[lijn_nummer][0],route[lijn_nummer + 1][1])

        #Hoek berekenen huidig en volgende lijn:
        hoek = math.degrees(math.acos((A * A + B * B - C * C)/(2.0 * B * C)))
        #graden die de gebruiker moet zien:
        hoek = 180 - hoek
        return hoek

def eindRoute(huidige_positie, lijn_eind, route_eind, afstand_trigger):

    if lijn_eind == route_eind:

        afstand_tot_eind = haversine(huidige_positie, route_eind) * 1000

        if afstand_tot_eind < afstand_trigger:
            return 1
        else:
            return 0

    else:
        return 0

def importShpFile(database, srid, shapefile):

    table_name = shapefile
    stuff = subprocess.call(["spatialite_tool", "-i", "-shp", str(shapefile), "-d", str(database), "-t", str(table_name), "-c", "UTF-8", "-s", str(srid)], shell=True)
    print(stuff)

def checkBlunder(huidige_positie, vorige_positie, huidige_positie_tijd, vorige_positie_tijd, max_afwijking_blunder):
    huidige_positie_tijd = huidige_positie_tijd.replace(':', '')
    vorige_positie_tijd = vorige_positie_tijd.replace(':', '')
    huidige_positie_tijd = huidige_positie_tijd.replace('.', '')
    vorige_positie_tijd = vorige_positie_tijd.replace('.', '')

    tijdsverschil_seconden = (int(huidige_positie_tijd) - int(vorige_positie_tijd)) / 1000

    max_afwijking_blunder = max_afwijking_blunder * tijdsverschil_seconden

    afwijking_huidige_positie = haversine(vorige_positie,huidige_positie) * 1000

    if afwijking_huidige_positie > max_afwijking_blunder:

        print('tijdsverschil:', tijdsverschil_seconden)
        print('max_afwijking_blunder:', max_afwijking_blunder)
        print('afwijking_huidige_positie:', afwijking_huidige_positie)

        return True
    else:
        return False
