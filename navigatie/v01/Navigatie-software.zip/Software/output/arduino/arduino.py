import serial
import time, os
ser = serial.Serial('COM5',9600)
check = ser.isOpen()

filename = 'output.txt'
file = open(filename,'r')

#Find the size of the file and move to the end
st_results = os.stat(filename)
st_size = st_results[6]
file.seek(st_size)

while 1:

    where = file.tell()
    line = file.readline()
    if not line:
        time.sleep(1)
        file.seek(where)
    else:
        # split the text
        #print(line)
        lijst = line.split(',')
        #print(lijst)
       
        datum = lijst[0]
        tijd = lijst[1]
        longitude = lijst[2]
        latitude = lijst[3]
        afstand_tov_ref = lijst[4]
        afstand_tov_eind_lijn = lijst[5]
        kant_van_lijn = lijst[6]
        azimuth_lijn = lijst[7]
        azimuth_eind_lijn = lijst[8]
        bocht = lijst[9]
        Hoek_boch = lijst[10]

        som = float(azimuth_eind_lijn) - float(azimuth_lijn)
        #print(som)

        hoek = 90 - som
       
        hoek = int(hoek)
        
        if bocht == 'rechts':
            hoek = 90 - float(Hoek_boch)
            hoek = int(hoek)
            data = str(hoek) + "," + kant_van_lijn + "\n"
            print("bocht naar rechts")
            #bocht.
            i = 0
            while i < 4:
                ser.write(data.encode())
                time.sleep(1)
                i = i + 1
                
        if bocht == 'links':
            hoek = 90 + float(Hoek_boch)
            hoek = int(hoek)
            data = str(hoek) + "," + kant_van_lijn + "\n"
            print("bocht naar links")
            #bocht.
            i = 0
            while i < 4:
                ser.write(data.encode())
                time.sleep(1)
                i = i + 1
        
        data = str(hoek) + "," + kant_van_lijn + "\n"
        print(data)   
        ser.write(data.encode())
