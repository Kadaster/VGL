#Auteurs: G. Roelofs, T. Dantuma, J. Klinkhamer, T. Iedema, M. Jahangier.

import sqlite3 #Database
import spatialite #Geometrische en spatial gerelateerde functions
import gui #Gui gerelateerde functies
from haversine import haversine #berekent de afstand tussen 2 coordinaten in km
import math
import time, os
import sys
import filehandler
import configparser
from websocket import create_connection

try:
    ws = create_connection("ws://127.0.0.1:12345/")
    print('Connected to websocket')
except ConnectionRefusedError:
    ws = False

#Configuratie gegevens:
def ConfigSectionMap(section):
    dict1 = {}
    options = Config.options(section)
    for option in options:
        try:
            dict1[option] = Config.get(section, option)
            if dict1[option] == -1:
                DebugPrint("skip: %s" % option)
        except:
            print("exception on %s!" % option)
            dict1[option] = None
    return dict1

Config = configparser.ConfigParser()
Config.read("configuration.ini")

srid = str(ConfigSectionMap("Algemeen")['srid'])
referentie_afstand = float(ConfigSectionMap("Algemeen")['referentie_afstand'])
afstand_trigger = float(ConfigSectionMap("Algemeen")['afstand_trigger'])
database = str(ConfigSectionMap("Algemeen")['database'])
max_afwijking_blunder = float(ConfigSectionMap("Algemeen")['max_afwijking_blunder'])



global running #Global variabel om script te laten wachten tot er een route gekozen.
running = False #Als running True wordt is er een route gekozen en wacht eht script op een positie in het bestand .log.
global route
route = '' #Variabel die de gekozen route bevat, wordt gevuld als er een route is gekozen.

#connectie met de database maken
conn = spatialite.connect(database)  #conn wordt dus het database object.

#shapefile = 'testimportshp'
#spatialite.importShpFile(database, srid, shapefile)

routes = spatialite.getRoutes(conn) #routes ophalen uit de database
gui.setRoutes(routes) #routes kenbaar maken voor de gui package (declareren)
gui.createGui() #gui creeren

#global om script te starten als route gekozen is
while running == False:
    route = gui.getGekozenRoute()
    if route == '':
        #print('wachten..')
        gui.nGui.update()
    else:
        print('route gekozen')
        running = True

#Onderstaande code wordt uitgevoerd als er een route gekozen is.

#Bestandsnaam en openen als alleen lezen.
filename = 'ReadLog.log'
file = open(filename,'r')

#Bestandgrote doorzoeken en de laatste regel zoeken.
st_results = os.stat(filename)
st_size = st_results[6]
file.seek(st_size)

#Geplande Route uit database ophalen & Bewerken tot bruikbare variabelen.
global geplande_route
geplande_route = spatialite.getRoute(conn, route)
global geplande_route_start
geplande_route_start = spatialite.getStartRoute(geplande_route)
global geplande_route_eind
geplande_route_eind = spatialite.getEindRoute(geplande_route)
#print(geplande_route)
#Eerste lijn van de route: (lijst met keys [0][1][2][3]).
global lijn_nummer
lijn_nummer = 0 #[0] is dus lijn 1 van de route.
#zet lijn nummer in gui
gui.updateLijnNummer(lijn_nummer)
#creer het output text bestand.
output_log = filehandler.createFile()
#Multi lijn creeren; referentie punten op de lijn toevoegen.
global interpolated_lijn
interpolated_lijn = spatialite.interpolate(geplande_route[lijn_nummer], referentie_afstand)
#Start en eind van de huidige lijn vast stellen.
global lijn_start
lijn_start = geplande_route[lijn_nummer][0]
global lijn_eind
lijn_eind = geplande_route[lijn_nummer][1]

global vorige_positie_tijd
vorige_positie_tijd = False
global vorige_positie
vorige_positie = False
global metingen
metingen = 0

#global bestemming
#bestemming = False

#Eeuwige loop die op een positie wacht.
while 1:
    where = file.tell()
    line = file.readline()
    if not line:
        gui.nGui.update()
        time.sleep(1)
        file.seek(where)
    else:
        xcoordinaat='';
        ycoordinaat='';
        #Split the text
        lijst = line.split()
        #For each word in the line:
        for word in lijst:
            #Posities van coordinaten in de lijst vanuit het bestand.
            datum = lijst[0]
            tijd = lijst[1]
            xcoordinaat = lijst[3];
            ycoordinaat = lijst[2];

        #Huidige positie wegschrijven.
        huidige_positie = float(ycoordinaat), float(xcoordinaat)

        #filter blunders.
        if metingen > 1:
            blunder = spatialite.checkBlunder(huidige_positie, vorige_positie, tijd, vorige_positie_tijd, max_afwijking_blunder)
        else:
            blunder = False

        metingen = metingen + 1

        if(blunder):
            print("Deze positie is een blunder en wordt genegeerd")
        else:
            vorige_positie_tijd = tijd
            vorige_positie = huidige_positie

            #Dichtbijzijnste punt in lijn vinden.
            ref_punt = spatialite.getReferentiePunt(interpolated_lijn, huidige_positie)

            #test gegeven afstand huidige positie ten opzichte van eind punt
            afstand_huidig_eindlijn = haversine(huidige_positie, lijn_eind) * 1000

            #Controlleer of het einde van de route bereikt is.
            if spatialite.eindRoute(huidige_positie, lijn_eind, geplande_route_eind, afstand_trigger):

                #bestemming = True
                #log tijd van stopppen
                if(ws != False):
                    data = 'bestemming'
                    try:
                        ws.send(data)
                    except:
                        print('websocket connection lost')
                        ws = False
                
                data = [str(datum),',',
                        str(tijd),',',
                        str(huidige_positie[1]), ",",
                        str(huidige_positie[0]), ",",
                        'Bestemming bereikt']
                filehandler.writeToFile(output_log, data)
                gui.updateRichtingText('Bestemming bereikt')
                print("Bestemming bereikt")
                sys.exit("Bestemming bereikt")

            #Graden van de huidige lijn bepalen.
            graden_lijn = spatialite.getGradenLijn(conn,lijn_start,lijn_eind)
            #Graden van referentie tot huidige positie bepalen om kant van de lijn te bepalen (links of rechts).
            graden_huidige_positie = spatialite.getGradenLijn(conn,ref_punt,huidige_positie)
            #Graden huidige positie t.o.v het einde van de huidige lijn bepalen.
            graden_positie_eind = spatialite.getGradenLijn(conn,huidige_positie, lijn_eind)

            #Som berekenen voor de GUI (Dus 17 graden in Azimuth moet 287 graden voor de GUI zijn, de som is dan 17).
            #Cirkel AZIMUTH: (Noord - 0, Oost - 90, West - 270, Zuid - 180).
            #CirkelGui: (Noord - 270, Oost - 0, West - 180, Zuid - 90).
            #print('graden_positie_eind',graden_positie_eind)
            #print('graden_lijn',graden_lijn)
            som = graden_positie_eind - graden_lijn

            #Afstand tot huidige referentie punt op de lijn bepalen in meters.
            afstand_tot_ref = haversine(huidige_positie, ref_punt) * 1000

            #te lopen lijn bepalen.
            update_lijn = spatialite.updateLijn(huidige_positie, lijn_eind, afstand_trigger)

            #controlleer op test debug next lijn.
            if gui.lijnnummer_update == True:
                update_lijn = True
                gui.setLijnnummerUpdate(False)

            #als updatelijn niet False is staan we bij een knooppunt en pakt het systeem een nieuwe lijn.
            if update_lijn == True:
                Kant_van_lijn_text = ""
                #hoek van de te nemen bocht berekenen.
                hoek_volgende_lijn = spatialite.getHoekVolgendeLijn(geplande_route, lijn_nummer)
                
                #richting op Azimuth bepalen van de nieuwe lijn.
                graden_volgende_lijn = spatialite.getGradenLijn(conn,geplande_route[lijn_nummer + 1][0], geplande_route[lijn_nummer + 1][1])
                #print('graden_huidige_lijn', graden_lijn)
                #print('graden_volgende_lijn', graden_volgende_lijn)
                #positie rechts of links t.o.v. de lijn bepalen.
                if spatialite.rechtsVanLijn(graden_lijn,graden_volgende_lijn):
                    Richting = "Rechts", hoek_volgende_lijn, 'Azimuth richting',graden_volgende_lijn
                    gui.updateRichtingText('Ga rechts')
                    bocht_text = 'rechts'

                else:
                    Richting = "Links", hoek_volgende_lijn, 'Azimuth richting',graden_volgende_lijn
                    gui.updateRichtingText('Ga links')
                    bocht_text = 'links'

                #er is een bocht, dit willen we zichtbaar maken in de gui, me overschrijven dus de gui met de nieuwe gegevens
                som = graden_volgende_lijn - graden_lijn

                #update bocht in gui.
                gui.updateBocht(hoek_volgende_lijn)

                #volgende lijn pakken.
                lijn_nummer = lijn_nummer + 1
                #zet nieuw nummer in gui
                gui.updateLijnNummer(lijn_nummer)

                #update lijn gegevens:
                interpolated_lijn = spatialite.interpolate(geplande_route[lijn_nummer], referentie_afstand)
                lijn_start = geplande_route[lijn_nummer][0]
                lijn_eind = geplande_route[lijn_nummer][1]
                print("Nieuwe lijn gepakt.")
                print("Lijn nummer: ", lijn_nummer + 1)
                print(Richting)

            else:
                hoek_volgende_lijn = False
                bocht_text = False
                #er is geen bocht, deze mag weg
                gui.updateBocht(False)
                #positie rechts of links t.o.v. de lijn bepalen.
                if (spatialite.rechtsVanLijn(graden_lijn,graden_huidige_positie)):
                    print("Je loopt rechts van de lijn op een afstand van ", "%.3f" % afstand_tot_ref, 'meter')
                    gui.updateRichtingText('Ga links')
                    Kant_van_lijn_text = "rechts"
                else:
                    print("Je loopt links van de lijn op een afstand van ", "%.3f" % afstand_tot_ref, 'meter')
                    gui.updateRichtingText('Ga rechts')
                    Kant_van_lijn_text = "links"

            #update GUI.
            gui.updateAfstandEind(afstand_huidig_eindlijn)
            gui.updateAfstand(afstand_tot_ref)
            gui.updateRichting(som)

            #log resultaten
            data = [str(datum), ",",
                    str(tijd), ",",
                    str(huidige_positie[1]), ",",
                    str(huidige_positie[0]), ",",
                    str(afstand_tot_ref), ",",
                    str(afstand_huidig_eindlijn), ",",
                    str(Kant_van_lijn_text), ",",
                    str(graden_lijn), ",",
                    str(graden_positie_eind), ",",
                    str(bocht_text), ",",
                    str(hoek_volgende_lijn), "\n"]
            filehandler.writeToFile(output_log, data)

            if(ws != False):
                data = str(datum) + "," + str(tijd) + "," + str(huidige_positie[1]) + "," + str(huidige_positie[0]) + "," + str(afstand_tot_ref) + "," + str(afstand_huidig_eindlijn) + "," + str(Kant_van_lijn_text) + "," + str(graden_lijn) + "," + str(graden_positie_eind) + "," + str(bocht_text) + "," + str(hoek_volgende_lijn);
                try:
                    ws.send(data)
                except:
                    print('websocket connection lost')
                    ws = False
